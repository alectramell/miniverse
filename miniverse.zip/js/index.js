function openHome() {
	window.open('index.html','MiniVerse','nonresizable,height=645,width=1041');
	return false;
}

function goLab() {
	top.window.location.href='lab.html';
}

function goHome() {
	top.window.location.href='index.html';
}

function goExit() {
	top.window.location.href='exit.html';
}
