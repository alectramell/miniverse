function openHome() {
	window.open('index.html','MiniVerse','nonresizable,height=645,width=1041');
	return false;
}

function goLab() {
	window.location.href='lab.html';
}

function goHome() {
	window.location.href='index.html';
}
