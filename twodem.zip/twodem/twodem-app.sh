#!/bin/bash

clear

USERNAME=$(whoami)
WHEREAMI=$(pwd)

clear

firefox --width="546" --height="716" file:///home/$USERNAME/Desktop/twodem/index.html &

clear
