#!/bin/bash

clear

USERNAME=$(whoami)
WHEREAMI=$(pwd)

clear

rm twodim.zip

clear

sleep 0.5

clear

zip -r twodim.zip *.html *.json js img audio fonts
