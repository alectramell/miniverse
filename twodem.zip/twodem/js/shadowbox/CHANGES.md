= HEAD

  * Reorganized and greatly simplified the code and build process.

  * Added support for video playback using HTML5 with Flash fallback. Video
    playback via Windows Media Player and QuickTime browser plugins is no longer
    supported.

  * Added support for live triggering of Shadowbox. This removes the need for
    manual setup/caching, and makes it easier to trigger Shadowbox on
    dynamically generated DOM elements. Thanks to Diego Perini for his ideas
    in this area.

  * Added support for WebKit on iPhone and Android.

  * Added support for Internet Explorer 9.

  * Require HTML5 doctype.

  * Removed dependency on JavaScript frameworks such as jQuery, swfobject,
    Sizzle, etc.

  * Removed CSS selector support.

  * Removed dependence on sniffing for various operating systems.

  * Removed dependency on various language-specific files.

  * Removed inline and html players.

  * Dropped support for Internet Explorer 6.
